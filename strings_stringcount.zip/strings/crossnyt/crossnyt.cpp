#include<iostream>
#include<string>
#include<conio.h>

using namespace std;

int main(){

	string str1 = "	"; // empty string to store my name and surname
	int countA = 0;
	int countE = 0;   


		cout << "Enter your Name and Surname:" << endl;
		getline(cin, str1); // this function method used to allow insertion of name and surname giving ability to press space bar to sepaarate 

		cout << "You have entered:" << str1 << endl;

	for (int x = 0; x < str1.length(); x++){ // the length method used to return length of the string

		if (str1[x] == 'a' || str1[x] == 'A'){ // search and compare a 

			countA += 1;

			}
		if (str1[x] == 'e' || str1[x] == 'E'){ 

			countE += 1;

			}
		
	}

	cout << "The number of times A's appear is:" << countA << endl;
	cout << "The number of times E appear is:" << countE << endl;




	getch();
	return 0;
}