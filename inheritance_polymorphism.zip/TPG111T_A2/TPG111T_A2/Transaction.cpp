//Total[5]
#include"Transaction.hpp"


Transaction::Transaction()
{
        accountNumber = 0;
        transactionType = 0;		//(1)
        transactionAmount = 0.0;
}
void Transaction::setTransaction(int acc, int type, float amt)
{
        accountNumber = acc;
        transactionType = type;		//(1)
        transactionAmount = amt;
}

int Transaction::getAccountNumber()
{
        return accountNumber;
}

float Transaction::getTransactionAmnt()
{
        switch (transactionType) //(1)
        {
           case 1 : 
			   return -transactionAmount; //(1)
           case 2 : 
			   return transactionAmount; //(1)
           default : 
			   return 0;
        }
}