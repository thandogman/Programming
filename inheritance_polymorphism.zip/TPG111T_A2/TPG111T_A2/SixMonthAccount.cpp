//Total[7]
#include "SixMonthAccount.hpp"


SixMonthAccount::SixMonthAccount(): Account() //(1)
{
	clubFee = 0.0;
}  
void SixMonthAccount::setAccount(int acc, char n[], char s[],char aCat, int rCat, float bal)
{
	Account::setAccount(acc,n,s,aCat,rCat,bal); //(1)
	clubFee = 25.0; //(1)
}
float SixMonthAccount::determineAmountPayable()
{
        float amntPayable = balance / 6;     //(1)

        if (amntPayable < 100.00) //(1)
                amntPayable = 100.00; //(1)

        amntPayable += clubFee;   //(1)
        return amntPayable;
}