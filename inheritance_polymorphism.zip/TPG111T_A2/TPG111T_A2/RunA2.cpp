//BIG TOTAL[]
//Total[7]
#include<iostream>
#include"Transaction.hpp"
#include"Account.hpp"
#include"SixMonthAccount.hpp"
	using namespace std;

	void displayAccount(Account& acc);
	void enterAccount(Account& acc);
	int enterTransactions (Transaction transAct[]);

	int main()
	{
		int numTrans;
		Account::readAndSetCreditLimits("creditlimits.csv"); //(1)

		SixMonthAccount six; //(1)
		Transaction transAct[10];//(1)
		
		enterAccount(six); //(1)

		
        numTrans = enterTransactions(transAct); //(1)

		for (int x=0; x < numTrans; x++)
        {
			six.purchase(transAct[x]); //(1)
           
        }
		displayAccount(six); //(1)


	
		system("pause");
		return 0;
	}