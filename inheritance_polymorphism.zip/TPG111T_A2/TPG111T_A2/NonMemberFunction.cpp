//Total[12]

#include<iostream>
#include"Transaction.hpp"
#include"Account.hpp"
#include"SixMonthAccount.hpp"
	using namespace std;


int enterTransactions (Transaction transAct[])  //(1)
{
        int accountNumber;
        int transactionType;
        float transactionAmount;
        int x = 0;

        char answer = 'Y';

        do		
		{
                  cout << "For transaction " << x+1 << " enter:\n";
                  cout << "\tAccount number: ";
                  cin >> accountNumber;
                  cout << "\tTransaction type (1 for payment,2 for purchase): ";
                  cin >> transactionType;
                  cout << "\tTransaction amount: R";
                  cin >> transactionAmount;

				  transAct[x].setTransaction(accountNumber, transactionType, transactionAmount); //(2)
                
                  cout << "Do you want to enter another transaction? (Y for yes, N for no) ";
				  cin >> answer;
		  x++;
		}
        while (toupper(answer) == 'Y' && x < 10); //(1)
                		
        return x-1; //(1)
}		
void enterAccount(Account& acc) //(1)
{
        int accountNumber;
        char name[MAX];
        char surname[MAX];
        char accountCategory;
        int repaymentCategory;
        float balance;

        cout << "For the account enter:\n";
		cout << "\tAccount number: " ;
		cin >> accountNumber;
        cout << "\tFirst name: ";
		cin >> name;
   		cout << "\tSurname: ";
		cin >> surname;
   		cout << "\tAccount Category:\n";
		cout << "\tEnter:\tP for Platinum\n";
      	cout << "\tEnter:\tG for Gold\n";
      	cout << "\tEnter:\tS for Silver\n";
      	cout << "\tEnter:\tB for Bronze\n\t";
		cin >> accountCategory;
        cout << "Repayment Category (1, 2 or 3): ";
        cin >> repaymentCategory;
   		cout << "Current Balance: ";
		cin >> balance;
		

		acc.setAccount(accountNumber,name,surname,accountCategory,repaymentCategory,balance);  //(2) 
}
void displayAccount(Account& acc)
{
		int accountNumber;
        char name[MAX];
        char surname[MAX];
        string accountCategory;
        float amntPayable;

		acc.getAccount(accountNumber, name, surname, accountCategory);//(1)
			
		amntPayable = acc.determineAmountPayable();   //(1)

		cout << "Amount due for " << accountCategory;

		cout << " account " << accountNumber << " - "
             << name << ' '<< surname << " is R" << amntPayable << endl; //(2)
				

}