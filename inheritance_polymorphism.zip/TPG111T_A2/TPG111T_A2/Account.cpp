//Total[37]

#include"Account.hpp"


char Account::accCategories[ROWS]={'P', 'G', 'S', 'B'};	//(1)
string Account::accCatDesc[ROWS]={"Platinum", "Gold", "Siver", "Bronze"}; //(1)
float Account::creditLimit[ROWS][COLS]={0.0}; //(1)


Account::Account()
{
	accountNumber = 0;
	name[0] = '\0';    //(1)
	surname[0] = '\0';
	accountCategory = ' ';
	repaymentCategory = 0;
	balance = 0.0;
}
void Account::setAccount(int acc, char n[], char s[],char aCat, int rCat, float bal)
{
	accountNumber = acc;
	strcpy_s(name,n); //(1)
	strcpy_s(surname,s); //(1)
	accountCategory = aCat;
	repaymentCategory = rCat;
	balance = bal;

}
void Account::readAndSetCreditLimits(string fileName)
{
       ifstream input; //(1)
	   input.open(fileName.c_str()); //(1)
                         
       if (!input)    
       {
         cout<< "File " << fileName << " could not be opened"<<endl; //(1)
                      
       }

       string line;     
       int row = 0;
       int end;
       while (getline(input, line))    //(2)
       {
          for (int col=0; col < COLS; col++)  //(1) 
          {
                end = line.find(",");          //(1)
                creditLimit[row][col] = atof(line.substr(0, end).c_str()); //(2)
                line = line.erase(0, (end + 1)); //(1)
          }
          row++;   //(1)
       }
}
float Account::calculateCreditLimit()
{
        int row, col;
        switch(accountCategory)       //(1) 
        {
           case 'P' : row = 0; break;
           case 'G' : row = 1; break;  //(3)
           case 'S' : row = 2; break;
           case 'B' : row = 3; break;
           default  : row = 0;
        }
        col = repaymentCategory-1;    

        return creditLimit[row][col];  //(2)
}
void Account::purchase(Transaction tr)	//(1)
{						
        float transAmnt;
        if (accountNumber == tr.getAccountNumber())  //(1)
        {
            transAmnt = tr.getTransactionAmnt();//(1)
            if (transAmnt <= 0)	    //(1)
            {
                balance += transAmnt;	//(1)
            }
            else
                if ((balance + transAmnt) > calculateCreditLimit()) //(2)
                {				
                   cout << "Credit limit exceeded - transaction not applied\n";
                }
                else
                {
                    balance += transAmnt;	//(1)
                }
         }
         else
         {
            cout << "Cannot apply transaction. Account numbers do not match\n"; //(1)
         }				

}
float Account::getBalance()
{
        return balance;    //(1)
}
void Account::getAccount(int &acc, char n[], char s[], string &aC)
{		
        acc = accountNumber;
        strcpy(n,name);   //(1)
        strcpy(s, surname);
        for (int accCat=0; accCat < COLS; accCat++) //(1)
        {
                if(accountCategory == accCategories[accCat]) //(1)
                {
                   aC = accCatDesc[accCat]; //(1)
                   break;
                }
        }
		
}