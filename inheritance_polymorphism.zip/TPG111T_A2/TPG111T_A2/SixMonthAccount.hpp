//Total[2]
#ifndef SixMonthAccount_hpp
#define SixMonthAccount_hpp
#include"Account.hpp"



class SixMonthAccount : public Account   //(1)
{
  protected:
         float clubFee;    
  public:
        SixMonthAccount();
		void setAccount(int, char[],char[],char,int,float); //(1)
        float determineAmountPayable();  
};
#endif