//Total[2]
#ifndef Transaction_hpp
#define Transaction_hpp


class Transaction
{
	private:
        int accountNumber;
        int transactionType;	//(1)
        float transactionAmount;
  public:
        Transaction();
        void setTransaction(int, int, float); //(1)
        int getAccountNumber();
        float getTransactionAmnt();

};
#endif