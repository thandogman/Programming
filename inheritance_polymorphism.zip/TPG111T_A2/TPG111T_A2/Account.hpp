//Total[3]
#ifndef Account_hpp
#define Account_hpp
#include<string>
#include<fstream>
#include<iostream>
#include"Transaction.hpp"	
	using namespace std;


const int MAX = 30;
const int ROWS = 4;     
const int COLS = 3;
class Account
{
	 protected:     
        int accountNumber;
        char name[MAX];	
        char surname[MAX];			
        char accountCategory;
        int repaymentCategory;
		float balance;

        static char accCategories[ROWS];  
        static string accCatDesc[ROWS];			//(1)
        static float creditLimit[ROWS][COLS];                      
        
	public:
        Account();
        void setAccount(int, char[], char[],char, int, float);
        static void readAndSetCreditLimits(string);
        float calculateCreditLimit();
        void purchase(Transaction);							//(1)
        virtual float determineAmountPayable(){return 0;};	//(1)
        float getBalance();
        void getAccount(int&, char[],char s[], string&);
};

#endif