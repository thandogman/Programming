#include "pch.h"
#include"Patient.hpp"
#include<iostream>
#include<String>

using namespace std;

Patient::Patient()
{
	name = " ";
	surname = " ";
	dob = 0;
	weight = 0.0;
	height = 0.0;
}

void Patient::setName(string nme)
{
	name = nme;
}

void Patient::setSurname(string sn)
{

	surname = sn;
}
void Patient::setDob(int birth)
{
	dob = birth;
}
void Patient::setWeight(double wg)
{
	weight = wg;
}
void Patient::setHeight(double ht)
{
	height = ht;
}
string Patient::getName()
{
	return name;
}
string Patient::getSurname()
{
	return surname;
}
int Patient::getDob()
{
	int currentYear = 2020;
	int age = 0;
	age = currentYear - dob;
	return age;
}
double Patient::getWeight()
{
	return weight;
}
double Patient::getHeight()
{
	return height;
}
double Patient::calcBMI()
{
	return (weight / height * height);
}
double Patient::calcRate()
{
	return (220 - getDob());
}