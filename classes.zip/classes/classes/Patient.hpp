#pragma once
#include<iostream>
#include<string>

#ifndef  Patient_hpp
#define Patient_hpp

using namespace std;

class Patient
{
private:
	string name;
	string surname;
	int dob;
	double weight;
	double height;

public:
	Patient();
	void setName(string);
	void setSurname(string);
	void setDob(int);
	void setWeight(double);
	void setHeight(double);
	string getName();
	string getSurname();
	int getDob();
	double getWeight();
	double getHeight();
	double calcBMI();
	double calcRate();



};


#endif // ! Patient_hpp
