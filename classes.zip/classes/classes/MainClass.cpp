// classes.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include "pch.h"
#include <iostream>
#include"Patient.hpp"

using namespace std;

int main()
{
	Patient MyPatient;
	string name, surname;
	int dob;
	double weight, height;
	cout << "******************************************" << endl;
	cout << "* Welcome to the healthcare Care System * " << endl;
	cout << "******************************************" << endl;
	
	cout << "Please enter patient's name: " << endl;
	cin >> name;
    cout << "Please enter patient's name: " << endl;
	cin >> surname;
	cout << "Please enter patient's date of birth: " << endl;
	cin >> dob;
	cout << "Please enter patient's weight in kilograms: " << endl;
	cin >> weight;
	cout << "Please enter patient's height in metres: " << endl;
	cin >> height;
	MyPatient.setName(name);
	MyPatient.setSurname(surname);
	MyPatient.setDob(dob);
	MyPatient.setWeight(weight);
	MyPatient.setHeight(height);

	cout << "Patient's report:" << endl;
	cout << "********************************************" << endl;
	cout << "Name: " << MyPatient.getName() << endl;
	cout << "Surname:" << MyPatient.getSurname() << endl;
	cout << "BMI:" << MyPatient.calcBMI() << endl;
	cout << "Max Heart Rate:" << MyPatient.calcRate() << endl;



	system("pause");
}

