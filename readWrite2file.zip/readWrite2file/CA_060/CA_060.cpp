/* COMPOSITION
Task: This project serves to read in the subject and marks of 4 students and saves them inside
a comma-delimited text file: "StudentsMarks.csv". The input comes from the user.

The initial layout of the two important classes to be used is provided.
The main()-method has to instantiate 4 students, read in the data for all subjects
or all 4 students AND save the information into the csv-file.
(It is your decision whether to add a non-member function for "writing the data
to file".)

Also try to add a new subject for a student ....        */

#include "stdafx.h"
#include <iostream>
#include <string>
#include <fstream>
#include <sstream>
#include <iomanip>

using namespace std;


// class declaration section
//=========================================================================================
class Date
{
private:
	int month;
	int day;
	int year;
public:
	Date(int = 7, int = 4, int = 2012); // constructor
	void setDate(int, int, int);   // member method to copy a date
	string showDate();               // member method to display a date
};
// class implementation section

Date::Date(int mm, int dd, int yyyy)
{
	month = mm;
	day = dd;
	year = yyyy;
}
void Date::setDate(int mm, int dd, int yyyy)
{
	month = mm;
	day = dd;
	year = yyyy;
	return;
}

string Date::showDate()
{
	stringstream stemp;

	stemp << "The date is ";
	stemp << setfill('0');
	
	stemp << setw(2) << year % 100 << '/'
		<< setw(2) << month << '/'
		<< setw(2) << day;	// extract the last 2 year digits
	stemp << endl;

	return stemp.str();
}

//----------------------------------------------------------- Class Date

class Subject
{
private:
	string subjectCode;	// eg: TPG111T
	double mark;		// eg: 65    [%]
public:
	Subject();
	void setSubject(string subjctC, double mrk);
	double getSubjectMark();
	string getSubjCode();

};
// implementation ============---------------==============================
Subject::Subject()
{
	subjectCode = ""; 
    mark = 0.0;
}
void Subject::setSubject(string sCode, double sMark)
{
	subjectCode = sCode;
	mark = sMark;
}											
string Subject::getSubjCode()
{
	return subjectCode;
}

double Subject::getSubjectMark()
{
	return mark;
}


//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
class Student
{
private:
	string studentNo;	// eg: "111222333"
	int amntOfSubj;		// eg: 3
	Date sDOB;          // Student HAS A DOB (Composition)
	Subject subj[7];    // maximum subjects allowed => 7     // =>> 7 subjects INSTATIATED HERE!  (Student HAS 7 subjects)
public:
	Student();
	void setStudNo(string studN, int amngOfSub);
	void setSubject(int count, string subjCode, double subjMark);	// !

	void setStudentDOB(string SDB);

	string getStudNo();
	int getAmntOfSubj();

	void displayStudent(int num);
};
// implementation ============ ========================================
Student::Student()
{
	studentNo = "";
	amntOfSubj = 0;
	sDOB.setDate(1, 1, 2000);
}

void Student::setStudNo(string studN, int amountOfS)
{
	studentNo = studN;
	amntOfSubj = amountOfS;
}
void Student::setStudentDOB(string SDB) // 19931014
{
	int Y, M, D;

	Y = atoi(SDB.substr(0, 4).c_str());

	M = atoi(SDB.substr(4, 2).c_str());

	D = atoi(SDB.substr(6, 2).c_str());

	sDOB.setDate(M, D, Y);

}
void Student::setSubject(int count, string subjCode, double subjMark)		// !!!!
{
	subj[count].setSubject(subjCode, subjMark);			
}
string Student::getStudNo()
{
	return studentNo;
}
int Student::getAmntOfSubj()
{
	return amntOfSubj;
}




void Student::displayStudent(int num)
{	
	// single students output WITH subjects:
	cout << "Student " << num+1 << " with student number: " << studentNo << "\t(" << amntOfSubj << " subjects)" << " born on " << sDOB.showDate();
	for (int g = 0; g < amntOfSubj; g++)
		cout << "\tSubject " << g + 1 << ":  " << subj[g].getSubjCode() << "\t" << subj[g].getSubjectMark() << "%" << endl;
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
int main()
{
	Student students[10];
	const int max = 3;

	ofstream outFile;
	string fileName = "StudentsMarks.csv";

	string subjCodeTmp;
	double markTmp;
	string studNoTmp;
	string sStudDOB;
	int amntSubjTmp;
	int count = 0;

	while (count < max)
	{
		cout << "Enter "<< count +1 <<". Student Number: ";
		cin >> studNoTmp;
		cout << "\nEnter the student DOB";
		cin >> sStudDOB;
		cout << "Enter Number of subjects: ";
		cin >> amntSubjTmp;
		students[count].setStudNo(studNoTmp, amntSubjTmp);
		students[count].setStudentDOB(sStudDOB);

		for (int i = 0; i < amntSubjTmp; i++)
		{
			cout << "Enter Subject code: ";
			cin >> subjCodeTmp;
			cout << "Enter mark[%]: ";
			cin >> markTmp;
			students[count].setSubject(i, subjCodeTmp, markTmp);	// in one line!
		}
		count++;
	}
	cout << "\n===== Captured Students DISPLAYED ======: " << endl;
	for (int t = 0; t < max; t++)
		students[t].displayStudent(t);

	// Write data to comma-delimited file - skip connection test 





	system("pause");
	return 0;
}

